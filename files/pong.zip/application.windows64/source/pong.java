import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class pong extends PApplet {

int Xballe = 100;
int Yballe = 200;
int rayon = 17;
int Xmove = 10;
int Ymove = 10;
int largeur = 100;
int score=0;
boolean jouer = true;

public void setup(){

}

public void draw(){
if(jouer == true){
  background(0,148,182);
  Score();
  balle();
  moveBalle();
  rebond();
  raquette();
}
if (jouer == false)exit(); 
}

public void Score(){
textSize(35);
String str = str(score);
if(score<9){
  text(str,950,50);
}else{
  text(str,925,50);
}
line(940,15,980,15);
line(940,60,980,60);
line(940,15,940,60);
line(980,15,980,60);
}

public void balle(){
fill(48,0,108);
ellipse(Xballe, Yballe, rayon, rayon);
}

public void moveBalle(){
Xballe = Xballe + Xmove;
Yballe = Yballe + Ymove;
}

public void rebond(){
if (Xballe > width) Xmove = -Xmove;
if (Xballe < 1) Xmove = -Xmove;
if (Yballe > height) Ymove = -Ymove;
if (Yballe < 1) Ymove = -Ymove;
if (Xballe < 25){
  if (Yballe > mouseY){
    if (Yballe < mouseY+largeur) {
      Xmove = -Xmove;
      score++;
    }
}  }

if (Xballe < 20){
  exit();
    //stop();
    //textSize(60);
    //fill(255,10,10);
    //text("appuyez sur Entrée ",220,200);
    //text("pour recommencer",220,300);
    
 
}}


public void raquette(){
fill(48,0,108);
rect(15, mouseY, 10, largeur);
}
  public void settings() { 
size(1000,600); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "pong" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
