import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Map; 
import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Soupe extends PApplet {

int acauldron = 2;
int ingame = 0;
String acniveau;
int legumes=0;
 
public void setup(){
  
  initmenu();
  initaudio();
  thread("Petit");
  thread("AnimationG");
}
 
public void draw(){
  fill(255,255,255);
  rect(0,0,1000,900);
  if(ingame==1){
    drawgame();
  }else if(ingame==0){
    drawmenu();
  }else if(ingame ==2  ){
    fill(0,255,0);
    textSize(200);
    text("GAGNÉ",200,500);
  }else if(ingame==3){
    fill(0,255,0);
    textSize(200);
    text("PERDU",200,500);
  }
}
  
public void mouseReleased(){
  if(ingame==1){
    a:for(GButton b : buttonl){
       if(b.isclicked(mouseX,mouseY)){
        switch(b.name){
          case "Fini":
            if(checkwin(inputs)){
              ingame=2;
              gagne.rewind();
              gagne.play();
              end();
              break a;
            }else{
              perdu.rewind();
              perdu.play();
              ingame=3;
              end();
              break a;
            }
          case "Consigne":thread("audioConsigne");break a;
          case "Retour":ingame=0;end();break a;
        }
        if(legumes!=11){
        llist.add(new DLegume(275,0,275, 450 ,b.image));
        legumes++;
        addtomapbystr(b.name,inputs); 
        }
      }
    }
    }else if(ingame==0){
      for(MButton b : button){
        if(b.Clicked(mouseX,mouseY)){
          acniveau=b.name;
          ingame=1;
          init(); 
        }
      }
    }else{
      ingame=0;
    }
  }
  
  public void mouseMoved(){
  if(ingame==1){
   for(GButton b : buttonl){
     if(b.name.equals("Retour")){
       b.image=portefermee;   
      }
    if(b.isclicked(mouseX,mouseY)){
      if(b.name.equals("Retour")){
       b.image=porteouverte; 
      }
     if(b.add<20){
      b.add+=4; 
     }

    }
   }

  }else{
         for(MButton b : button){
        if(b.Clicked(mouseX,mouseY)){
          if(b.add<10){
            b.add+=4; 
         }
        }
      }    
    
  }
  if(bsoundPlay){
    thread("bsound");
  }
  }

  public void Petit(){
  while(true){
    try{
     for(GButton b : buttonl){
      if(b.add>0 && !b.clicked){
        b.add--;
      }
     }
     for(MButton b : button){
      if(b.add>0 && !b.clicked){
        b.add--;
      }
     }
    }catch(Exception e){}
    delay(10);
  }
}

public void stop(){
  minim.stop();
  super.stop();
}

PImage cauldron;
PImage patate,poireau,oignon,navet,courgette,carotte,bulle,loupe,porteouverte,portefermee,ok;
ArrayList<GButton> buttonl= new ArrayList();
ArrayList<GButton> grossir = new ArrayList();
ArrayList<Bulle> blist = new ArrayList();
ArrayList<DLegume> llist = new ArrayList();
boolean aend = false;
HashMap<String,Integer> consignes = new HashMap();
HashMap<String,Integer> base = new HashMap();
HashMap<String,Integer> inputs = new HashMap();

public void init(){
  base.put("Patate",0);
  base.put("Poireau",0);
  base.put("Oignon",0);
  base.put("Courgette",0);
  base.put("Carotte",0);
  base.put("Navet",0);
  inputs=(HashMap<String,Integer>)base.clone();
  
  cauldron=loadImage("chaudron.png");
  bulle=loadImage("bulle.png");
  patate=loadImage("patate.png");
  poireau=loadImage("poireau.png");
  oignon=loadImage("oignon.png");
  navet=loadImage("navet.png");
  courgette=loadImage("courgette.png");
  carotte=loadImage("carotte.png");
  loupe=loadImage("Loupe.png");
  porteouverte=loadImage("porteouverte.png");
  portefermee=loadImage("portefermée.png");
  ok=loadImage("ok.png");

  buttonl.add(new GButton(600,100,150,"Patate",patate));
  buttonl.add(new GButton(600,350,150,"Poireau",poireau));
  buttonl.add(new GButton(600,600,150,"Oignon",oignon));
  buttonl.add(new GButton(800,100,150,"Courgette",courgette));
  buttonl.add(new GButton(800,350,150,"Carotte",carotte));
  buttonl.add(new GButton(800,600,150,"Navet",navet)); 
  buttonl.add(new GButton(21,729,150,"Fini",ok));
  buttonl.add(new GButton(349,729,150,"Consigne",loupe));
  buttonl.add(new GButton(21,21,150,"Retour",portefermee));
   
  switch(acniveau){
    case "FACILE":consignes=generateconsig(5);break;
    case "MOYEN":consignes=generateconsig(6);break;
    case "DIFFICILE":consignes=generateconsig(7);break;
  }
}

public void end(){
  llist.clear();
  legumes=0;
  buttonl.clear();
  base.clear();
}

public void drawgame(){
  fill(200,100,0);
  rect(550,0,1000,900);
  for(GButton b : buttonl){
    b.drawButton(); 
  }
  fill(0,0,0);
  for(int i=0;i<blist.size();i++){
    blist.get(i).drawbulle(); 
  if(blist.get(i).hauteur>150){
    while(aend!=true){println("ata");}
        blist.remove(blist.indexOf(blist.get(i)));
     }
  }
  for(DLegume l : llist){
    l.drawpetitlegumes(); 
  }
  image(cauldron,20,0);
}

public void AnimationG(){
  while(true){
    aend=false;
    if(ingame==1){
        for(Bulle b :blist){
          b.hauteur+=1; 
        }
        if((int)random(0,100)<2){
         blist.add(new Bulle(0,(int)random(0,200))); 
        }
            for(DLegume p : llist){
      p.avancer();
    }
    }
    aend=true;
    delay(5);
  }
}


public HashMap<String,Integer> generateconsig(int taille){
  HashMap<String,Integer> map = (HashMap<String,Integer>)base.clone();
  for(int i=0;i<taille;i++){
    int rdm = (int)random(0,6);
    addtomapbyid(rdm,map);
  }
  return map;
}

public HashMap<String,Integer> addtomapbyid(int id,HashMap<String,Integer> map){
  switch(id){
    case 0:map.put("Patate",(map.get("Patate")+1));break;
    case 1:map.put("Poireau",map.get("Poireau")+1);break;
    case 2:map.put("Oignon",map.get("Oignon")+1);break;
    case 3:map.put("Courgette",map.get("Courgette")+1);break;
    case 4:map.put("Carotte",map.get("Carotte")+1);break;
    case 5:map.put("Navet",map.get("Navet")+1);break;
  }
  return map;
}

public HashMap<String,Integer> addtomapbystr(String name,HashMap<String,Integer> map){
  switch(name){
    case "Patate":map.put("Patate",map.get("Patate")+1);break;
    case "Poireau":map.put("Poireau",map.get("Poireau")+1);break;
    case "Oignon":map.put("Oignon",map.get("Oignon")+1);break;
    case "Courgette":map.put("Courgette",map.get("Courgette")+1);break;
    case "Carotte":map.put("Carotte",map.get("Carotte")+1);break;
    case "Navet":map.put("Navet",map.get("Navet")+1);break;
  }
  return map;
}

public boolean checkwin(HashMap<String,Integer> map){
  if(map.get("Patate")!=consignes.get("Patate"))return false;
  if(map.get("Poireau")!=consignes.get("Poireau"))return false;
  if(map.get("Oignon")!=consignes.get("Oignon"))return false;
  if(map.get("Courgette")!=consignes.get("Courgette"))return false;
  if(map.get("Carotte")!=consignes.get("Carotte"))return false;
  if(map.get("Navet")!=consignes.get("Navet"))return false;
  return true;
}
PImage star;
ArrayList<MButton> button = new ArrayList();

public void initmenu(){
  star=loadImage("star.png");
  addmbutton(new MButton(350,200,1,300,100,"FACILE"));
  addmbutton(new MButton(350,350,2,300,100,"MOYEN"));
  addmbutton(new MButton(350,500,3,300,100,"DIFFICILE"));
}


public void drawmenu(){
  fill(255,255,255);
  rect(0,0,1000,900);
  background(255, 127, 0);
  textSize(75);
  fill(58, 242, 75) ;
  text("LA SOUPE ",(width/2)-215,75);
  text("INTERACTIVE ",(width/2)-300,150);
  for (MButton bt : button){
    bt.draw();
  }
}

public void addmbutton(MButton bt){
  button.add(bt);
}


boolean bplay = true;
boolean bsoundPlay = true;
AudioSnippet soupe,un,une,deux,trois,quatre,cinq,six,pat,nav,car,oig,cou,poi,gagne,perdu,porte,menu,consigne,verif,facile,moyen,difficile;
Minim minim;

public void initaudio(){
  minim = new Minim(this);
  gagne = minim.loadSnippet("gagne.wav");
  perdu = minim.loadSnippet("perdu.wav");
  porte = minim.loadSnippet("porte.wav");
  menu = minim.loadSnippet("menu.wav");
  consigne = minim.loadSnippet("consigne.wav");
  verif = minim.loadSnippet("reponse.wav");
  facile = minim.loadSnippet("facile.wav");
  moyen = minim.loadSnippet("moyen.wav");
  difficile = minim.loadSnippet("difficile.wav");
  soupe = minim.loadSnippet("soupe (1).wav");
  un = minim.loadSnippet("un.wav");
  une = minim.loadSnippet("une.wav");
  deux = minim.loadSnippet("deux.wav");
  trois = minim.loadSnippet("trois.wav");
  quatre = minim.loadSnippet("quatre.wav");
  cinq = minim.loadSnippet("cinq.wav");
  six = minim.loadSnippet("six.wav");
  pat = minim.loadSnippet("patate.wav");
  nav = minim.loadSnippet("navet.wav");
  car = minim.loadSnippet("carotte.wav");
  oig = minim.loadSnippet("OIGNONS.wav");
  cou = minim.loadSnippet("courgettes.wav");
  poi = minim.loadSnippet("poireau.wav");
}

public void audioConsigne(){
  bplay = false; 
  println("Dans ma soupe, il y a :");
  soupe.rewind();
  soupe.play();
  delay(2000);
  for(Map.Entry m : consignes.entrySet()){
    if((int)m.getValue()!=0){
      switch((String)m.getKey()){
        case "Patate":println(m.getValue() + " Patates");        //Patates
          switch((int)m.getValue()){
            case 1:une.rewind();une.play();delay(2000);break;
            case 2:deux.rewind();deux.play();delay(2000);break;
            case 3:trois.rewind();trois.play();delay(2000);break;
            case 4:quatre.rewind();quatre.play();delay(2000);break;
            case 5:cinq.rewind();cinq.play();delay(2000);break;
            case 6:six.rewind();six.play();delay(2000);break;
          }
        pat.rewind();
        pat.play();
        delay(2000);
        break;
        case "Poireau":println(m.getValue() + " Poireaux");      //Poireaux
        switch((int)m.getValue()){
            case 1:un.rewind();un.play();delay(2000);break;
            case 2:deux.rewind();deux.play();delay(2000);break;
            case 3:trois.rewind();trois.play();delay(2000);break;
            case 4:quatre.rewind();quatre.play();delay(2000);break;
            case 5:cinq.rewind();cinq.play();delay(2000);break;
            case 6:six.rewind();six.play();delay(2000);break;
          }
        poi.rewind();
        poi.play();
        delay(2000);
        break;
        case "Oignon":println(m.getValue() + " Oignons");      //oignons
        switch((int)m.getValue()){
            case 1:un.rewind();un.play();delay(2000);break;
            case 2:deux.rewind();deux.play();delay(2000);break;
            case 3:trois.rewind();trois.play();delay(2000);break;
            case 4:quatre.rewind();quatre.play();delay(2000);break;
            case 5:cinq.rewind();cinq.play();delay(2000);break;
            case 6:six.rewind();six.play();delay(2000);break;
          }
        oig.rewind();
        oig.play();
        delay(2000);
        break;
        case "Courgette":println(m.getValue() + " Courgettes");    //Courgettes
        switch((int)m.getValue()){
            case 1:une.rewind();une.play();delay(2000);break;
            case 2:deux.rewind();deux.play();delay(2000);break;
            case 3:trois.rewind();trois.play();delay(2000);break;
            case 4:quatre.rewind();quatre.play();delay(2000);break;
            case 5:cinq.rewind();cinq.play();delay(2000);break;
            case 6:six.rewind();six.play();delay(2000);break;
          }
          cou.rewind();
          cou.play();
          delay(2000);
          break;
        case "Carotte":println(m.getValue() + " Carottes");        //Caroottes
        switch((int)m.getValue()){
            case 1:une.rewind();une.play();delay(2000);break;
            case 2:deux.rewind();deux.play();delay(2000);break;
            case 3:trois.rewind();trois.play();delay(2000);break;
            case 4:quatre.rewind();quatre.play();delay(2000);break;
            case 5:cinq.rewind();cinq.play();delay(2000);break;
            case 6:six.rewind();six.play();delay(2000);break;
          }
          car.rewind();
          car.play();
          delay(2000);
        break;
        case "Navet":println(m.getValue() + " Navets");        //navets
        switch((int)m.getValue()){
            case 1:un.rewind();un.play();delay(2000);break;
            case 2:deux.rewind();deux.play();delay(2000);break;
            case 3:trois.rewind();trois.play();delay(2000);break;
            case 4:quatre.rewind();quatre.play();delay(2000);break;
            case 5:cinq.rewind();cinq.play();delay(2000);break;
            case 6:six.rewind();six.play();delay(2000);break;
          }
          nav.rewind();
          nav.play();
          delay(2000);
        break;
      }
    }
  }
  bplay = true;
}

  public void bsound(){
    bsoundPlay = false;
    if(ingame==1){
    for(GButton b : buttonl){
      if(b.isclicked(mouseX,mouseY)){
        if(b.name.equals("Retour")){
          menu.rewind();
          menu.play();
          delay(2000);
        }
        if(b.name.equals("Fini")){
          verif.rewind();
          verif.play();
          delay(2000);
        }
        if(b.name.equals("Consigne")){
          consigne.rewind();
          consigne.play();
          delay(2000);
        }
        }  
      }
    }
    if(ingame==0){
      for(MButton m : button){
        if(m.Clicked(mouseX,mouseY)){
          if(m.name.equals("FACILE")){
            facile.rewind();
            facile.play();
            delay(2000);
          }
          if(m.name.equals("MOYEN")){
            moyen.rewind();
            moyen.play();
            delay(2000);
          }
          if(m.name.equals("DIFFICILE")){
            difficile.rewind();
            difficile.play();
            delay(2000);
          }
        }
      }
    }
    bsoundPlay = true;
  }
class Bulle{
  int hauteur,decalage;
  Bulle(int hauteur,int decalage){
    this.hauteur=hauteur;
    this.decalage=decalage;
  }
  
  public void drawbulle(){
    image(bulle,175+this.decalage,300-this.hauteur);  
  }
}
class DLegume{
 int x,y,xa,ya,dx,dy;
 PImage image;
 
 DLegume(int x,int y,int xa,int ya,PImage image){
   this.x=x;
   this.y=y;
   this.dx=x;
   this.dy=y;
   this.xa=xa;
   this.ya=ya;
   this.image=image;
 }
 
 public void drawpetitlegumes(){
   image(this.image,this.x,this.y,100,100);
 }
 
 public void avancer(){
    if(this.xa-this.dx>0){
      if(this.x<this.xa){
        this.x++;
        if(this.y>0){
          this.y--;
        }
      }else{ 
        if(this.y<this.ya){
          this.y++; 
        }else{
          return; 
      }
    }
   }else{
     if(this.x>this.xa){
       this.x--;
       if(this.y>0){
         this.y--;
       } 
     }else{
       if(this.dy>this.ya){
         if(this.y>this.ya){
           if(this.y>0){
             this.y--;
           } 
         }else{
           this.y++; 
         }
       }else{
         if(this.y<this.ya){
           this.y++; 
         }else{
           return; 
         }  
       }
     }
   }
 }
 
}
class GButton{
  int add;
  int x,y,largeur;
  String name;
  PImage image;
  boolean clicked;
  
  GButton(int x,int y,int largeur,String name,PImage image){
    this.add=0;
    this.x=x;
    this.y=y;
    this.largeur=largeur;
    this.name=name;
    this.image=image;
  }
 
  public void drawButton(){
    fill(255,255,255);
    image(this.image,this.x+1-add,this.y+1-add,this.largeur-1+(add*2),this.largeur-40+(add*2));
    fill(0,0,0);
    textSize(this.largeur/8);
    text(this.name,this.x+(this.largeur/3),this.y+this.largeur-5+add);
  }
 
  public boolean isclicked(int x,int y){
    if(x>this.x && x<this.x+this.largeur && y>this.y && y<this.y+this.largeur){
      this.clicked=true;
      return true;
    }
    this.clicked=false;
    return false;
  }
}
class MButton{
  int x,y,nbe,longueur,hauteur,add;
  boolean clicked;
  String name;
  ArrayList<Stars> etoiles = new ArrayList();
  MButton(int x, int y, int nbe,int longueur,int hauteur,String name){
    this.add=0;
    this.clicked=false;
    this.x=x;
    this.y=y;
    this.nbe=nbe;
    this.name=name;
    this.longueur=longueur;
    this.hauteur=hauteur;
    for (int i=0;i<nbe;i++){
      etoiles.add(new Stars(this.x+25+i*50-nbe*25,this.y));
    }
  }

  public void draw(){
    fill(255, 203, 96);
    rect(this.x-this.add,this.y-this.add,this.longueur+this.add*2,this.hauteur+this.add*2);
    for (Stars st : etoiles){
      st.draw(this,this.add);
    }
    fill(255,10,10);
    textSize(35);
    if(nbe==0){
      text(name,x+longueur/2-textWidth(name)/2,y+60-add);
    }else{
       text(name,x+longueur/2-textWidth(name)/2,y+40-add);
    }
  }
  
  public boolean Clicked(int mx, int my){
    if(mx>this.x && mx<(this.x+this.longueur) && my>this.y && my<this.y+this.hauteur){
      this.clicked=true;
      return true;
    }
    this.clicked=false;
    return false;
    }
  }
class Stars{
  int x,y;
  Stars(int x, int y){
    this.x=x;
    this.y=y;
  }

  public void draw(MButton bt,int add){
    image(star,this.x+(bt.longueur/2)-25-add,this.y+50-add,50+add*2,50+add*2);
  }
  
}
  public void settings() {  size(1000,900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Soupe" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
